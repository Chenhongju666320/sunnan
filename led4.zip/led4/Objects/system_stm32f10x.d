./objects/system_stm32f10x.o: RTE\Device\STM32F103C8\system_stm32f10x.c \
  D:\mdk\Packs\Keil\STM32F1xx_DFP\2.4.1\Device\Include\stm32f10x.h \
  RTE\_Target_1\RTE_Components.h \
  D:\mdk\Packs\ARM\CMSIS\6.2.0\CMSIS\Core\Include\core_cm3.h \
  D:\mdk\Packs\Keil\STM32F1xx_DFP\2.4.1\Device\Include\system_stm32f10x.h
